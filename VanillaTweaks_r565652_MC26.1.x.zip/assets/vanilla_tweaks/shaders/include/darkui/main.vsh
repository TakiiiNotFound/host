#define NEW_INVENTORY_TEXT_COLOUR 0xbcbcbc


bool darkui_ingui(mat4 projectionMat) {
    return projectionMat[2][3] == 0.0;
}
int darkui_toint(vec3 col) {
  ivec3 icol = ivec3(col*255);
  return (icol.r << 16) + (icol.g << 8) + icol.b;
}
vec3 darkui_tovec(int col) {
    return vec3(col >> 16, (col >> 8) % 256, col % 256) / 255.;
}

#define ORIGINAL_INVENTORY_TEXT_COLOUR 0x404040

vec4 darkui_recolourText(vec4 colourAttribute, mat4 projectionMatrix) {
    if(!darkui_ingui(projectionMatrix)) return colourAttribute;

    if(darkui_toint(colourAttribute.rgb) == ORIGINAL_INVENTORY_TEXT_COLOUR) {
        return vec4(darkui_tovec(NEW_INVENTORY_TEXT_COLOUR), colourAttribute.a);
    }
    return colourAttribute;
}